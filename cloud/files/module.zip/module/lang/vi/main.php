<?php
$_L['trafficdetails']                	=  'Chi tiết truy cập';
$_L['topvisit']                			=  'Trang truy cập nhiều nhất';
$_L['topbrowse']                		=  'Trình duyệt nhiều nhất';
$_L['trafficdashboard']                	=  'Truy cập dashboard';
$_L['neworders']                		=  'Đơn hàng mới';
$_L['userregistrations']                =  'Thành viên mới';
$_L['uniquevisitors']                	=  'Tổng truy cập';
$_L['moreinfo']                			=  'Xem thông tin';


$_L['error_user']                		=  'Tên tài khoản của bạn đã có người sử dụng.';
$_L['succ_user']                		=  'Tên tài khoản của bạn có thể sử dụng.';
$_L['error_email']                		=  'Email của bạn đã có người sử dụng.';
$_L['succ_email']                		=  'Email của bạn có thể sử dụng.';
$_L['pass-repass']                		=  'Mật khẩu của bạn không khớp';


$_L['success_user']                		=  'Bạn đã tạo tài khoản thành công.';