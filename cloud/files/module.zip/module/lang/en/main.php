<?php
$_L['trafficdetails']                	=  'Traffic Details';
$_L['topvisit']                			=  'Top Most Visit Pages';
$_L['topbrowse']                		=  'Top Browses';
$_L['trafficdashboard']                	=  'Traffic Dashboard';
$_L['neworders']                		=  'New Orders';
$_L['userregistrations']                =  'User Registrations';
$_L['uniquevisitors']                	=  'Unique Visitors';
$_L['moreinfo']                			=  'More info';



//Lang Erro
$_L['error_user']                		=  'Your Username has users.';
$_L['succ_user']                		=  'Your Username may be used.';
$_L['error_email']                		=  'Your Email has users.';
$_L['succ_email']                		=  'Your Email may be used.';
$_L['pass-repass']                		=  'Your passwords do not match.';


$_L['success_user']                		=  'You have successfully created your account.';

