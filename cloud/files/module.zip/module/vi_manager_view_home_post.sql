/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : core_db

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-03-01 10:29:12
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `vi_manager_view_home_post`
-- ----------------------------
DROP TABLE IF EXISTS `vi_manager_view_home_post`;
CREATE TABLE `vi_manager_view_home_post` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `content` longtext CHARACTER SET utf8,
  `type` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `create_author` int(11) DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `update_author` int(11) DEFAULT NULL,
  `update_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of vi_manager_view_home_post
-- ----------------------------
INSERT INTO vi_manager_view_home_post VALUES ('16', 'Bóng Đá Ngoại Hạng Anh', '[{\"id\":2,\"title\":\"B\\u00e0i vi\\u1ebft s\\u1ed1 2\",\"alias\":\"bai-viet-so-2\",\"description\":\"hay l\\u1eafm\",\"content\":\"&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The implode() function accept its parameters in either order. However, for consistency with&amp;nbsp;&lt;a href=&quot;\\\\&quot;&gt;explode()&lt;\\/a&gt;, you should use the documented order of arguments.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The separator parameter of implode() is optional. However, it is recommended to always use two parameters for backwards compatibility.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;This function is binary-safe.&lt;\\/p&gt;\\r\\n\",\"cate_id\":\",1,3,\",\"thumbnail\":\"dt2_1.png\",\"tags\":\"note,hay,tu,te\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1475204145\",\"update_time\":\"1488302303\"},{\"id\":4,\"title\":\"dfgdfg\",\"alias\":\"dfgdfg\",\"description\":\"dfgdfg\",\"content\":\"\",\"cate_id\":\",1,\",\"thumbnail\":\"favicon.ico\",\"tags\":\"\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1476248427\",\"update_time\":\"1488302484\"}]', null, '0', '1', '37', '1488302828', '37', '1488307237');
INSERT INTO vi_manager_view_home_post VALUES ('17', 'Bóng Chày Nước Mỹ', '[{\"id\":4,\"title\":\"dfgdfg\",\"alias\":\"dfgdfg\",\"description\":\"dfgdfg\",\"content\":\"\",\"cate_id\":\",1,\",\"thumbnail\":\"favicon.ico\",\"tags\":\"\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1476248427\",\"update_time\":\"1488302484\"},{\"id\":2,\"title\":\"B\\u00e0i vi\\u1ebft s\\u1ed1 2\",\"alias\":\"bai-viet-so-2\",\"description\":\"hay l\\u1eafm\",\"content\":\"&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The implode() function accept its parameters in either order. However, for consistency with&amp;nbsp;&lt;a href=&quot;\\\\&quot;&gt;explode()&lt;\\/a&gt;, you should use the documented order of arguments.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The separator parameter of implode() is optional. However, it is recommended to always use two parameters for backwards compatibility.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;This function is binary-safe.&lt;\\/p&gt;\\r\\n\",\"cate_id\":\",1,3,\",\"thumbnail\":\"dt2_1.png\",\"tags\":\"note,hay,tu,te\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1475204145\",\"update_time\":\"1488302303\"}]', null, '2', '1', '37', '1488303465', '37', '1488307242');
INSERT INTO vi_manager_view_home_post VALUES ('18', 'Nhà cấp 4', '[{\"id\":4,\"title\":\"dfgdfg\",\"alias\":\"dfgdfg\",\"description\":\"dfgdfg\",\"content\":\"\",\"cate_id\":\",1,\",\"thumbnail\":\"favicon.ico\",\"tags\":\"\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1476248427\",\"update_time\":\"1488302484\"},{\"id\":2,\"title\":\"B\\u00e0i vi\\u1ebft s\\u1ed1 2\",\"alias\":\"bai-viet-so-2\",\"description\":\"hay l\\u1eafm\",\"content\":\"&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The implode() function accept its parameters in either order. However, for consistency with&amp;nbsp;&lt;a href=&quot;\\\\&quot;&gt;explode()&lt;\\/a&gt;, you should use the documented order of arguments.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;The separator parameter of implode() is optional. However, it is recommended to always use two parameters for backwards compatibility.&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\\\r\\\\n\\\\r\\\\n&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;&lt;strong&gt;Note:&lt;\\/strong&gt;&amp;nbsp;This function is binary-safe.&lt;\\/p&gt;\\r\\n\",\"cate_id\":\",1,3,\",\"thumbnail\":\"dt2_1.png\",\"tags\":\"note,hay,tu,te\",\"note\":\"\",\"author_create\":23,\"author_update\":37,\"status\":1,\"create_time\":\"1475204145\",\"update_time\":\"1488302303\"}]', null, '1', '1', '37', '1488338657', null, null);
